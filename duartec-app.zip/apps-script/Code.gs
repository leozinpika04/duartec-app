/**
 * DUARTEC REFRIGERAÇÃO — Centro de Custos
 * API do app (Google Apps Script). Os dados ficam nas abas desta planilha.
 *
 * Primeira vez: recarregue a planilha → menu "Duartec" → "1. Configurar planilha".
 * Depois: Implantar → Nova implantação → App da Web
 *   Executar como: Eu  ·  Quem pode acessar: Qualquer pessoa
 * Copie a URL que termina em /exec e cole em www/config.js no GitHub.
 */

const ABAS = {
  Custos:     ['ID','Data','Mes','Categoria','Tipo','CentroCusto','OS','Veiculo','Funcionario','Fornecedor','Pagamento','Descricao','Valor','Litros','KM','Comprovante','Status','Exemplo','CriadoEm','LancadoPor'],
  Entradas:   ['ID','Data','Mes','Servico','Cliente','CentroCusto','OS','Funcionario','Recebimento','Descricao','Valor','Status','Exemplo','CriadoEm','LancadoPor'],
  Categorias: ['Nome','Icone','Orcamento','Tipos','Combustivel','Veiculo'],
  Servicos:   ['Nome','Icone','Meta','CentroCusto'],
  Centros:    ['Nome','Orcamento'],
  Veiculos:   ['Placa','Modelo'],
  Equipe:     ['Nome'],
  OS:         ['Codigo','Cliente','Valor'],
  Usuarios:   ['Nome','Perfil','Token','Ativo','CriadoEm'],
  Config:     ['Chave','Valor']
};

// campo do app  <->  coluna da planilha
const MAP_CUSTO = {id:'ID',data:'Data',mes:'Mes',cat:'Categoria',sub:'Tipo',cc:'CentroCusto',os:'OS',veic:'Veiculo',func:'Funcionario',forn:'Fornecedor',pag:'Pagamento',desc:'Descricao',total:'Valor',litros:'Litros',km:'KM',foto:'Comprovante',status:'Status',exemplo:'Exemplo',criadoEm:'CriadoEm',por:'LancadoPor'};
const MAP_ENTRADA = {id:'ID',data:'Data',mes:'Mes',serv:'Servico',cliente:'Cliente',cc:'CentroCusto',os:'OS',func:'Funcionario',rec:'Recebimento',desc:'Descricao',total:'Valor',status:'Status',exemplo:'Exemplo',criadoEm:'CriadoEm',por:'LancadoPor'};

const PADRAO = {
  Categorias: [
    ['Combustível','fuel',3500,'Gasolina, Etanol, Diesel S10, Arla 32','S',''],
    ['Manutenção de veículos','car',1200,'Troca de óleo, Pneus, Revisão, Lavagem, Documentação','','S'],
    ['Pedágio e estacionamento','toll',200,'Pedágio, Estacionamento','',''],
    ['Gás refrigerante','gas',2500,'R-410A, R-32, R-22, R-134a, R-404A, Nitrogênio','',''],
    ['Peças e componentes','chip',4000,'Compressor, Capacitor, Placa eletrônica, Motor ventilador, Sensor, Válvula, Contatora, Filtro secador','',''],
    ['Tubulação e cobre','pipe',2200,'Cobre 1/4, Cobre 3/8, Cobre 1/2, Cobre 5/8, Conexões e solda','',''],
    ['Materiais de instalação','box',1500,'Suporte, Isolamento, Fita, Dreno, Cabo PP, Disjuntor, Parafusos e buchas','',''],
    ['Ferramentas','tool',800,'Bomba de vácuo, Manifold, Ferramenta manual, Solda, Instrumento de medição','',''],
    ['EPI e uniformes','shield',400,'Luva, Óculos, Cinto/talabarte, Botina, Uniforme','',''],
    ['Alimentação','food',1200,'Almoço, Lanche','',''],
    ['Hospedagem e viagem','bed',500,'Hotel, Passagem, Diária','',''],
    ['Mão de obra terceirizada','people',2000,'','',''],
    ['Aluguel','building',2500,'','',''],
    ['Energia, água e internet','bolt',600,'','',''],
    ['Telefonia','phone',300,'','',''],
    ['Sistemas','code',250,'','',''],
    ['Marketing','mega',500,'','',''],
    ['Impostos e taxas','receipt',1500,'','',''],
    ['Outros','dots',300,'','','']
  ],
  Servicos: [
    ['Instalação','ac',12000,'Instalação'],
    ['Pré-instalação','ruler',2000,'Instalação'],
    ['Manutenção preventiva (PMOC)','cal',6000,'Manutenção preventiva (PMOC)'],
    ['Manutenção corretiva','tool',5000,'Manutenção corretiva'],
    ['Higienização','drop',3000,'Manutenção preventiva (PMOC)'],
    ['Obras e projetos','building',8000,'Obras e projetos'],
    ['Outros serviços','dots',0,'Comercial']
  ],
  Centros: [['Instalação',6000],['Manutenção preventiva (PMOC)',4000],['Manutenção corretiva',4000],['Obras e projetos',5000],['Frota',5000],['Administrativo',5500],['Comercial',1000]],
  Veiculos: [],
  Equipe: [['Pedro Dias']],
  OS: [],
  Usuarios: [],
  Config: [['Empresa','Duartec Refrigeração'],['Pasta comprovantes','']]
};

/* ================= Menu e configuração ================= */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Duartec')
    .addItem('1. Configurar planilha', 'configurar')
    .addItem('Inserir dados de exemplo', 'inserirExemplos')
    .addItem('Apagar dados de exemplo', 'apagarExemplosMenu')
    .addToUi();
}

function configurar() {
  const ss = SpreadsheetApp.getActive();
  PropertiesService.getScriptProperties().setProperty('SS_ID', ss.getId());
  const cores = {Custos:'#0b8aa0', Entradas:'#3fd99a', Usuarios:'#f3b544'};
  Object.keys(ABAS).forEach((nome, i) => {
    let sh = ss.getSheetByName(nome);
    if (!sh) sh = ss.insertSheet(nome, i);
    const h = ABAS[nome];
    sh.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold').setFontColor('#ffffff').setBackground('#0b4f5c');
    sh.setFrozenRows(1);
    if (cores[nome]) sh.setTabColor(cores[nome]);
    if (nome === 'Usuarios') sh.getRange('C:C').setNumberFormat('@');
    if (nome === 'Custos' || nome === 'Entradas') {
      sh.getRange('B:C').setNumberFormat('@');                       // Data e Mês como texto (sem fuso)
      const colValor = h.indexOf('Valor') + 1;
      sh.getRange(2, colValor, sh.getMaxRows() - 1, 1).setNumberFormat('"R$" #,##0.00');
    }
    if (sh.getLastRow() < 2 && PADRAO[nome] && PADRAO[nome].length) {
      sh.getRange(2, 1, PADRAO[nome].length, h.length).setValues(PADRAO[nome]);
    }
    sh.autoResizeColumns(1, h.length);
  });
  const s1 = ss.getSheetByName('Página1') || ss.getSheetByName('Sheet1');
  if (s1 && s1.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(s1);
  let gestor = linhas_('Usuarios').find(r => String(r[1]) === 'Gestor' && ativo_(r[3]));
  if (!gestor) { gestor = ['Gestor', 'Gestor', novoToken_(), 'S', agora_()]; aba_('Usuarios').appendRow(gestor); }
  try {
    SpreadsheetApp.getUi().alert('Planilha configurada!\n\nSeu código de gestor: ' + gestor[2] +
      '\n(ele está na aba Usuarios; troque o nome "Gestor" pelo seu se quiser)\n\n' +
      'Agora: Extensões > Apps Script > Implantar > Nova implantação > App da Web\n' +
      'Executar como: Eu · Quem pode acessar: Qualquer pessoa');
  } catch (e) {}
}

/* ================= API (chamada pelo app) ================= */
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.action) return json_(executar_(p.action, p.u, p.args ? JSON.parse(p.args) : []));
  return json_({ok: true, app: 'Duartec Custos', mensagem: 'API ativa'});
}
function doPost(e) {
  let body = {};
  try { body = JSON.parse(e.postData.contents || '{}'); } catch (err) { return json_({ok: false, erro: 'Pedido inválido.'}); }
  return json_(executar_(body.action, body.u, body.args || []));
}

const ACOES = {
  quem:             {perfil: null,     fn: (u) => ({nome: u.nome, perfil: u.perfil, empresa: getConfig_('Empresa')})},
  carregar:         {perfil: null,     fn: (u, mes) => carregar_(u, mes)},
  salvarCusto:      {perfil: null,     fn: (u, o, foto) => salvarCusto_(u, o, foto)},
  salvarEntrada:    {perfil: null,     fn: (u, o) => salvarEntrada_(u, o)},
  excluir:          {perfil: null,     fn: (u, tipo, id) => excluir_(u, tipo, id)},
  mudarStatus:      {perfil: 'Gestor', fn: (u, tipo, id, st) => mudarStatus_(tipo, id, st)},
  aprovarPendentes: {perfil: 'Gestor', fn: (u, mes) => aprovarPendentes_(mes)},
  salvarCadastros:  {perfil: 'Gestor', fn: (u, cfg) => salvarCadastros_(cfg)},
  apagarExemplos:   {perfil: 'Gestor', fn: () => apagarExemplos_()},
  usuarios:         {perfil: 'Gestor', fn: () => usuarios_()},
  criarUsuario:     {perfil: 'Gestor', fn: (u, nome, perfil) => criarUsuario_(nome, perfil)},
  ativarUsuario:    {perfil: 'Gestor', fn: (u, token, ativo) => ativarUsuario_(u, token, ativo)}
};
function executar_(acao, token, args) {
  try {
    const def = ACOES[acao];
    if (!def) throw new Error('Ação desconhecida.');
    const u = usuario_(token);
    if (!u) throw new Error('ACESSO: Código de acesso inválido ou desativado. Peça um novo link ao gestor.');
    if (def.perfil && u.perfil !== def.perfil) throw new Error('Só o gestor pode fazer isso.');
    return {ok: true, data: def.fn.apply(null, [u].concat(args || []))};
  } catch (err) {
    return {ok: false, erro: String(err && err.message || err)};
  }
}

/* ================= Utilidades ================= */
function ss_() {
  const id = PropertiesService.getScriptProperties().getProperty('SS_ID');
  return id ? SpreadsheetApp.openById(id) : SpreadsheetApp.getActive();
}
function aba_(nome) {
  const sh = ss_().getSheetByName(nome);
  if (!sh) throw new Error('A aba "' + nome + '" não existe. Abra a planilha e rode Duartec > Configurar planilha.');
  return sh;
}
function tz_() { return ss_().getSpreadsheetTimeZone() || 'America/Cuiaba'; }
function txt_(v, fmt) {
  if (v instanceof Date) return Utilities.formatDate(v, tz_(), fmt || 'yyyy-MM-dd');
  return v == null ? '' : String(v);
}
function num_(v) {
  if (typeof v === 'number') return v;
  const s = String(v || '').replace(/[^\d,.-]/g, '');
  const n = parseFloat(s.indexOf(',') >= 0 ? s.replace(/\./g, '').replace(',', '.') : s);
  return isNaN(n) ? 0 : n;
}
function linhas_(nome) {
  const sh = aba_(nome);
  const last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, ABAS[nome].length).getValues().filter(r => r.join('') !== '');
}
function getConfig_(chave) {
  const r = linhas_('Config').find(l => String(l[0]).trim() === chave);
  return r ? String(r[1]).trim() : '';
}
function setConfig_(chave, valor) {
  const sh = aba_('Config');
  const v = sh.getDataRange().getValues();
  for (let i = 1; i < v.length; i++) if (String(v[i][0]).trim() === chave) { sh.getRange(i + 1, 2).setValue(valor); return; }
  sh.appendRow([chave, valor]);
}
function agora_() { return Utilities.formatDate(new Date(), tz_(), "yyyy-MM-dd'T'HH:mm:ss"); }
function ativo_(v) { return v === true || ['S', 'SIM', 'TRUE'].indexOf(String(v).trim().toUpperCase()) >= 0; }
function novoToken_() { return Utilities.getUuid().replace(/-/g, '').slice(0, 12).toUpperCase(); }
function usuario_(token) {
  token = String(token || '').trim().toUpperCase();
  if (token.length < 6) return null;
  const cache = CacheService.getScriptCache(), hit = cache.get('u_' + token);
  if (hit) return JSON.parse(hit);
  const r = linhas_('Usuarios').find(l => String(l[2]).trim().toUpperCase() === token && ativo_(l[3]));
  if (!r) return null;
  const u = {nome: String(r[0]).trim(), perfil: String(r[1]).trim() === 'Gestor' ? 'Gestor' : 'Técnico', token: token};
  cache.put('u_' + token, JSON.stringify(u), 300);
  return u;
}
function meses_(mes, n) {
  const [y, m] = mes.split('-').map(Number), out = [];
  for (let i = 0; i < n; i++) { const d = new Date(y, m - 1 - i, 1); out.push(d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2)); }
  return out;
}
function rowToObj_(row, nomeAba, map) {
  const h = ABAS[nomeAba], o = {};
  Object.keys(map).forEach(k => { o[k] = row[h.indexOf(map[k])]; });
  o.data = txt_(o.data); o.mes = txt_(o.mes, 'yyyy-MM'); o.criadoEm = txt_(o.criadoEm, "yyyy-MM-dd'T'HH:mm:ss");
  if (!o.mes && o.data) o.mes = o.data.slice(0, 7);
  o.total = num_(o.total); o.exemplo = o.exemplo === true || String(o.exemplo).toUpperCase() === 'TRUE' || o.exemplo === 'S';
  o.id = String(o.id);
  if ('litros' in o) { o.litros = o.litros === '' ? null : num_(o.litros); o.km = o.km === '' ? null : num_(o.km); }
  return o;
}
function objToRow_(o, nomeAba, map) {
  const h = ABAS[nomeAba], row = new Array(h.length).fill('');
  Object.keys(map).forEach(k => { const v = o[k]; row[h.indexOf(map[k])] = v == null ? '' : v; });
  return row;
}

/* ================= API chamada pelo app ================= */
function carregar_(u, mes) {
  if (!/^\d{4}-\d{2}$/.test(String(mes))) mes = Utilities.formatDate(new Date(), tz_(), 'yyyy-MM');
  const ms = meses_(mes, 6), gestor = u.perfil === 'Gestor';
  const meu = o => gestor || o.por === u.nome;
  const custos = linhas_('Custos').map(r => rowToObj_(r, 'Custos', MAP_CUSTO)).filter(o => ms.indexOf(o.mes) >= 0 && meu(o));
  const entradas = linhas_('Entradas').map(r => rowToObj_(r, 'Entradas', MAP_ENTRADA)).filter(o => ms.indexOf(o.mes) >= 0 && meu(o));
  if (!gestor) return { cfg: cadastros_(), custos, entradas, osTot: {}, user: {nome: u.nome, perfil: u.perfil}, agora: new Date().toISOString() };
  // valores acumulados por OS (todos os meses)
  const osTot = {};
  linhas_('Custos').forEach(r => { const o = rowToObj_(r, 'Custos', MAP_CUSTO); if (o.os && o.status !== 'Recusado') { osTot[o.os] = osTot[o.os] || {c:0, r:0}; osTot[o.os].c += o.total; } });
  linhas_('Entradas').forEach(r => { const o = rowToObj_(r, 'Entradas', MAP_ENTRADA); if (o.os) { osTot[o.os] = osTot[o.os] || {c:0, r:0}; osTot[o.os].r += o.total; } });
  return { cfg: cadastros_(), custos, entradas, osTot, user: {nome: u.nome, perfil: u.perfil}, agora: new Date().toISOString() };
}

function cadastros_() {
  const sn = v => String(v).trim().toUpperCase() === 'S';
  return {
    categorias: linhas_('Categorias').map(r => ({nome:String(r[0]), icon:String(r[1] || 'dots'), orc:num_(r[2]), sub:String(r[3] || ''), fuel:sn(r[4]), veic:sn(r[5])})),
    servicos:   linhas_('Servicos').map(r => ({nome:String(r[0]), icon:String(r[1] || 'dots'), meta:num_(r[2]), cc:String(r[3] || '')})),
    centros:    linhas_('Centros').map(r => ({nome:String(r[0]), orc:num_(r[1])})),
    veiculos:   linhas_('Veiculos').map(r => ({placa:String(r[0]), modelo:String(r[1] || '')})),
    equipe:     linhas_('Equipe').map(r => ({nome:String(r[0])})),
    os:         linhas_('OS').map(r => ({cod:String(r[0]), cliente:String(r[1] || ''), valor:num_(r[2])})),
    pagamentos: ['Cartão empresa','PIX','Dinheiro','Boleto','Reembolso'],
    recebimentos: ['PIX','Dinheiro','Cartão','Boleto','Transferência']
  };
}

function salvarCusto_(u, o, foto) {
  if (!o || !o.data || !o.cat || !(num_(o.total) > 0)) throw new Error('Preencha data, categoria e valor.');
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const item = Object.assign({}, o, {
      id: 'C' + Utilities.getUuid().slice(0, 8),
      mes: String(o.data).slice(0, 7),
      total: Math.round(num_(o.total) * 100) / 100,
      status: u.perfil === 'Gestor' ? 'Aprovado' : 'Pendente',
      exemplo: false, por: u.nome, func: o.func || u.nome,
      criadoEm: agora_()
    });
    if (foto && foto.base64) item.foto = salvarFoto_(foto, item);
    aba_('Custos').appendRow(objToRow_(item, 'Custos', MAP_CUSTO));
    return item;
  } finally { lock.releaseLock(); }
}

function salvarEntrada_(u, o) {
  if (!o || !o.data || !o.serv || !(num_(o.total) > 0)) throw new Error('Preencha data, serviço e valor.');
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    const item = Object.assign({}, o, {
      id: 'E' + Utilities.getUuid().slice(0, 8),
      mes: String(o.data).slice(0, 7),
      total: Math.round(num_(o.total) * 100) / 100,
      status: o.status === 'A receber' ? 'A receber' : 'Recebido',
      exemplo: false, por: u.nome, func: o.func || u.nome,
      criadoEm: agora_()
    });
    aba_('Entradas').appendRow(objToRow_(item, 'Entradas', MAP_ENTRADA));
    return item;
  } finally { lock.releaseLock(); }
}

function salvarFoto_(foto, item) {
  let pastaId = getConfig_('Pasta comprovantes'), pasta;
  try { pasta = pastaId ? DriveApp.getFolderById(pastaId) : null; } catch (e) { pasta = null; }
  if (!pasta) { pasta = DriveApp.createFolder('Duartec - Comprovantes'); setConfig_('Pasta comprovantes', pasta.getId()); }
  const blob = Utilities.newBlob(Utilities.base64Decode(foto.base64), foto.tipo || 'image/jpeg',
    item.data + '_' + (item.cat || 'gasto').replace(/[^\wÀ-ú]+/g, '-') + '_' + item.id + '.jpg');
  const f = pasta.createFile(blob);
  try { f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) {}
  return f.getId();
}

function acharLinha_(nomeAba, id) {
  const sh = aba_(nomeAba), last = sh.getLastRow();
  if (last < 2) return 0;
  const ids = sh.getRange(2, 1, last - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(id)) return i + 2;
  return 0;
}

function mudarStatus_(tipo, id, status) {
  const nome = tipo === 'entrada' ? 'Entradas' : 'Custos';
  const ok = tipo === 'entrada' ? ['Recebido', 'A receber'] : ['Pendente', 'Aprovado', 'Recusado'];
  if (ok.indexOf(status) < 0) throw new Error('Status inválido.');
  const ln = acharLinha_(nome, id); if (!ln) throw new Error('Lançamento não encontrado.');
  aba_(nome).getRange(ln, ABAS[nome].indexOf('Status') + 1).setValue(status);
  return true;
}

function aprovarPendentes_(mes) {
  const sh = aba_('Custos'), h = ABAS.Custos, last = sh.getLastRow();
  if (last < 2) return 0;
  const rng = sh.getRange(2, 1, last - 1, h.length), v = rng.getValues();
  let n = 0;
  v.forEach(r => { if (txt_(r[h.indexOf('Mes')], 'yyyy-MM') === mes && r[h.indexOf('Status')] === 'Pendente') { r[h.indexOf('Status')] = 'Aprovado'; n++; } });
  if (n) sh.getRange(2, h.indexOf('Status') + 1, v.length, 1).setValues(v.map(r => [r[h.indexOf('Status')]]));
  return n;
}

function excluir_(u, tipo, id) {
  const nome = tipo === 'entrada' ? 'Entradas' : 'Custos', h = ABAS[nome];
  const ln = acharLinha_(nome, id); if (!ln) throw new Error('Lançamento não encontrado.');
  if (u.perfil !== 'Gestor') {
    const r = aba_(nome).getRange(ln, 1, 1, h.length).getValues()[0];
    const dono = String(r[h.indexOf('LancadoPor')]) === u.nome;
    const recente = txt_(r[h.indexOf('CriadoEm')], "yyyy-MM-dd").slice(0, 10) === Utilities.formatDate(new Date(), tz_(), 'yyyy-MM-dd');
    const pend = nome === 'Entradas' || r[h.indexOf('Status')] === 'Pendente';
    if (!(dono && recente && pend)) throw new Error('Você só pode excluir lançamentos seus feitos hoje. Fale com o gestor.');
  }
  aba_(nome).deleteRow(ln);
  return true;
}

/* ================= Usuários ================= */
function usuarios_() {
  return linhas_('Usuarios').map(r => ({nome: String(r[0]), perfil: String(r[1]) === 'Gestor' ? 'Gestor' : 'Técnico', token: String(r[2]), ativo: ativo_(r[3]), criadoEm: txt_(r[4], 'yyyy-MM-dd')}));
}
function criarUsuario_(nome, perfil) {
  nome = String(nome || '').trim();
  if (!nome) throw new Error('Informe o nome.');
  if (linhas_('Usuarios').some(r => String(r[0]).trim().toLowerCase() === nome.toLowerCase() && ativo_(r[3]))) throw new Error('Já existe um usuário ativo com esse nome.');
  const u = [nome, perfil === 'Gestor' ? 'Gestor' : 'Técnico', novoToken_(), 'S', agora_()];
  aba_('Usuarios').appendRow(u);
  if (!linhas_('Equipe').some(r => String(r[0]).trim().toLowerCase() === nome.toLowerCase())) aba_('Equipe').appendRow([nome]);
  return {nome: u[0], perfil: u[1], token: u[2], ativo: true, criadoEm: u[4].slice(0, 10)};
}
function ativarUsuario_(eu, token, ativo) {
  if (!ativo && String(token).toUpperCase() === eu.token) throw new Error('Você não pode desativar o seu próprio acesso.');
  const sh = aba_('Usuarios'), v = sh.getDataRange().getValues();
  for (let i = 1; i < v.length; i++) if (String(v[i][2]).trim().toUpperCase() === String(token).toUpperCase()) {
    sh.getRange(i + 1, 4).setValue(ativo ? 'S' : 'N');
    CacheService.getScriptCache().remove('u_' + String(token).toUpperCase());
    return true;
  }
  throw new Error('Usuário não encontrado.');
}

function salvarCadastros_(cfg) {
  const sn = b => b ? 'S' : '';
  const dados = {
    Categorias: (cfg.categorias || []).filter(c => String(c.nome || '').trim()).map(c => [c.nome.trim(), c.icon || 'dots', num_(c.orc), c.sub || '', sn(c.fuel), sn(c.veic)]),
    Servicos:   (cfg.servicos || []).filter(c => String(c.nome || '').trim()).map(c => [c.nome.trim(), c.icon || 'dots', num_(c.meta), c.cc || '']),
    Centros:    (cfg.centros || []).filter(c => String(c.nome || '').trim()).map(c => [c.nome.trim(), num_(c.orc)]),
    Veiculos:   (cfg.veiculos || []).filter(v => String(v.placa || '').trim()).map(v => [v.placa.trim().toUpperCase(), v.modelo || '']),
    Equipe:     (cfg.equipe || []).filter(p => String(p.nome || '').trim()).map(p => [p.nome.trim()]),
    OS:         (cfg.os || []).filter(o => String(o.cod || '').trim()).map(o => [o.cod.trim(), o.cliente || '', num_(o.valor)])
  };
  Object.keys(dados).forEach(nome => {
    const sh = aba_(nome), w = ABAS[nome].length, last = sh.getLastRow();
    if (last > 1) sh.getRange(2, 1, last - 1, w).clearContent();
    if (dados[nome].length) sh.getRange(2, 1, dados[nome].length, w).setValues(dados[nome]);
  });
  return cadastros_();
}

/* ================= Exemplos ================= */
function apagarExemplosMenu() { const n = apagarExemplos_(); try { SpreadsheetApp.getUi().alert(n + ' linhas de exemplo apagadas.'); } catch (e) {} }
function apagarExemplos_() {
  let n = 0;
  ['Custos', 'Entradas'].forEach(nome => {
    const sh = aba_(nome), col = ABAS[nome].indexOf('Exemplo'), last = sh.getLastRow();
    if (last < 2) return;
    const v = sh.getRange(2, 1, last - 1, ABAS[nome].length).getValues();
    for (let i = v.length - 1; i >= 0; i--) if (v[i][col] === true || String(v[i][col]).toUpperCase() === 'TRUE') { sh.deleteRow(i + 2); n++; }
  });
  ['Veiculos', 'Equipe', 'OS'].forEach(nome => {
    const sh = aba_(nome), last = sh.getLastRow();
    if (last < 2) return;
    const v = sh.getRange(2, 1, last - 1, ABAS[nome].length).getValues();
    for (let i = v.length - 1; i >= 0; i--) if (/\(exemplo\)/i.test(v[i].join(' '))) { sh.deleteRow(i + 2); n++; }
  });
  return n;
}

function inserirExemplos() {
  const add = (nome, rows) => { if (rows.length) { const sh = aba_(nome); sh.getRange(sh.getLastRow() + 1, 1, rows.length, ABAS[nome].length).setValues(rows); } };
  if (!linhas_('Veiculos').length) add('Veiculos', [['AAA1A11', 'Fiat Strada (exemplo)'], ['BBB2B22', 'Fiat Fiorino (exemplo)']]);
  add('Equipe', [['Auxiliar (exemplo)']]);
  add('OS', [['OS-101', 'Cliente A (exemplo)', 7800], ['OS-102', 'Contrato PMOC (exemplo)', 3500], ['OS-103', 'Cliente C (exemplo)', 2900], ['OS-104', 'Câmara fria (exemplo)', 18000]]);
  const hoje = new Date(), rnd = (a, b) => Math.round((a + Math.random() * (b - a)) * 100) / 100;
  const dia = (mOff, d) => { const x = new Date(hoje.getFullYear(), hoje.getMonth() + mOff, 1); const lim = mOff === 0 ? hoje.getDate() : new Date(x.getFullYear(), x.getMonth() + 1, 0).getDate(); x.setDate(Math.min(d, lim)); return Utilities.formatDate(x, tz_(), 'yyyy-MM-dd'); };
  const custos = [], entradas = [], km = {AAA1A11: 48200, BBB2B22: 91500};
  const C = (data, cat, sub, cc, os, veic, func, forn, desc, total, pag, litros, kmv, st) => custos.push(objToRow_({id:'CX' + Utilities.getUuid().slice(0, 6), data, mes:data.slice(0, 7), cat, sub, cc, os, veic, func, forn, pag, desc, total, litros, km:kmv, foto:'', status:st || 'Aprovado', exemplo:true, criadoEm:data + 'T10:00:00', por:func || 'Gestor'}, 'Custos', MAP_CUSTO));
  const E = (data, serv, cliente, cc, os, func, rec, desc, total, st) => entradas.push(objToRow_({id:'EX' + Utilities.getUuid().slice(0, 6), data, mes:data.slice(0, 7), serv, cliente, cc, os, func, rec, desc, total, status:st || 'Recebido', exemplo:true, criadoEm:data + 'T15:00:00', por:func || 'Gestor'}, 'Entradas', MAP_ENTRADA));
  [-1, 0].forEach(mo => {
    [['AAA1A11', 'Pedro Dias'], ['BBB2B22', 'Auxiliar (exemplo)']].forEach(([v, f]) => {
      for (let i = 0; i < 4; i++) { const l = rnd(32, 44), p = rnd(6.09, 6.39); km[v] += 380 + Math.floor(Math.random() * 140); C(dia(mo, 2 + i * 7), 'Combustível', 'Gasolina', 'Frota', '', v, f, 'Posto Central (exemplo)', 'Abastecimento', Math.round(l * p * 100) / 100, 'Cartão empresa', l, km[v]); }
    });
    C(dia(mo, 4), 'Gás refrigerante', 'R-410A', 'Instalação', 'OS-101', '', 'Pedro Dias', 'Distribuidora Frio (exemplo)', 'Botijão R-410A 11,3 kg', rnd(620, 690), 'PIX');
    C(dia(mo, 6), 'Tubulação e cobre', 'Cobre 3/8', 'Instalação', 'OS-101', '', 'Pedro Dias', 'Casa do Cobre (exemplo)', 'Rolo cobre 3/8 15 m', rnd(390, 450), 'Cartão empresa');
    C(dia(mo, 9), 'Peças e componentes', 'Compressor', 'Manutenção corretiva', 'OS-103', '', 'Pedro Dias', 'Distribuidora Frio (exemplo)', 'Compressor rotativo 12k', rnd(980, 1250), 'Boleto');
    C(dia(mo, 11), 'Materiais de instalação', 'Isolamento', 'Obras e projetos', 'OS-104', '', 'Auxiliar (exemplo)', 'Elétrica Centro (exemplo)', 'Isolamento elastomérico 20 m', rnd(180, 260), 'PIX');
    C(dia(mo, 14), 'Alimentação', 'Almoço', 'Obras e projetos', 'OS-104', '', 'Auxiliar (exemplo)', 'Restaurante (exemplo)', 'Almoço equipe na obra', rnd(70, 110), 'Reembolso', '', '', mo === 0 ? 'Pendente' : 'Aprovado');
    C(dia(mo, 16), 'Ferramentas', 'Manifold', 'Manutenção preventiva (PMOC)', 'OS-102', '', 'Pedro Dias', 'Ferramentas (exemplo)', 'Manifold digital', rnd(890, 1100), 'Cartão empresa', '', '', mo === 0 ? 'Pendente' : 'Aprovado');
    C(dia(mo, 5), 'Aluguel', '', 'Administrativo', '', '', '', 'Imobiliária (exemplo)', 'Aluguel do galpão', 2400, 'Boleto');
    C(dia(mo, 12), 'Energia, água e internet', '', 'Administrativo', '', '', '', 'Concessionária (exemplo)', 'Energia + internet', rnd(480, 600), 'Boleto');
    E(dia(mo, 5), 'Instalação', 'Cliente A (exemplo)', 'Instalação', 'OS-101', 'Pedro Dias', 'PIX', '3 splits 12k', 3900);
    E(dia(mo, 8), 'Higienização', 'Clínica (exemplo)', 'Manutenção preventiva (PMOC)', '', 'Auxiliar (exemplo)', 'PIX', '6 aparelhos', rnd(900, 1200));
    E(dia(mo, 10), 'Manutenção preventiva (PMOC)', 'Contrato PMOC (exemplo)', 'Manutenção preventiva (PMOC)', 'OS-102', 'Pedro Dias', 'Boleto', 'Mensalidade PMOC', 3500);
    E(dia(mo, 13), 'Manutenção corretiva', 'Cliente C (exemplo)', 'Manutenção corretiva', 'OS-103', 'Pedro Dias', 'Cartão', 'Troca de compressor', 2900);
    E(dia(mo, 17), 'Instalação', 'Residência (exemplo)', 'Instalação', '', 'Pedro Dias', 'Dinheiro', 'Split 9k', rnd(650, 800));
    E(dia(mo, 20), 'Obras e projetos', 'Câmara fria (exemplo)', 'Obras e projetos', 'OS-104', 'Pedro Dias', 'Transferência', 'Parcela do projeto', 6000, mo === 0 ? 'A receber' : 'Recebido');
    E(dia(mo, 22), 'Pré-instalação', 'Construtora (exemplo)', 'Instalação', '', 'Auxiliar (exemplo)', 'PIX', 'Infra de 4 pontos', rnd(1200, 1600));
  });
  add('Custos', custos); add('Entradas', entradas);
  try { SpreadsheetApp.getUi().alert('Exemplos inseridos (' + custos.length + ' custos e ' + entradas.length + ' entradas). Apague pelo menu quando começar a usar.'); } catch (e) {}
}
