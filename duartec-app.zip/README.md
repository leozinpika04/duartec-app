# Duartec Custos

App de centro de custos da **Duartec Refrigeração**: técnicos lançam custos e serviços pelo celular e o gestor acompanha receita, custos e lucro do mês.

Os dados ficam numa **planilha do Google**. O GitHub gera o **APK para Android** e publica o app e as páginas de convite.

```
apps-script/Code.gs        API que grava na planilha (cole no Apps Script da planilha)
www/                       o app (painel, lançamentos, ajustes)
www/config.js              ← cole aqui a URL do Apps Script
site/index.html            página de convite: "Olá, Pedro → Baixar o app → Entrar"
android/                   APK (abre o app publicado; câmera para fotos de nota)
.github/workflows/build.yml  gera o APK e publica tudo no GitHub Pages
```

## Instalação (uma vez só)

### 1. Planilha
1. Crie uma planilha nova no Google Drive.
2. Abra **Extensões → Apps Script**, apague o conteúdo de `Código.gs` e cole o conteúdo de `apps-script/Code.gs`. Salve.
3. Volte à planilha, recarregue a página e use o menu **Duartec → 1. Configurar planilha**. Autorize quando o Google pedir.
   - Aparece o **seu código de gestor**. Ele também fica na aba **Usuarios**.
4. No Apps Script, vá em **Implantar → Nova implantação → App da Web**:
   - Executar como: **Eu**
   - Quem pode acessar: **Qualquer pessoa**
5. Copie a **URL que termina em `/exec`**.

### 2. GitHub
**2.1 Criar a conta (se ainda não tiver)**: entre em github.com → *Sign up*.

**2.2 Criar o repositório**
1. No canto superior direito, clique em **+ → New repository**.
2. *Repository name*: `duartec-app`
3. Marque **Public** (o GitHub Pages grátis só funciona em repositório público).
4. Marque **Add a README file**.
5. Clique em **Create repository**.

**2.3 Ligar o GitHub Pages (antes de enviar os arquivos)**
1. No repositório, clique em **Settings** (aba de cima, ícone de engrenagem).
2. No menu da esquerda, clique em **Pages**.
3. Em *Build and deployment → Source*, escolha **GitHub Actions**. Não precisa salvar, já fica valendo.

**2.4 Enviar o pacote (um arquivo só)**
1. Na aba **Code** do repositório, clique em **Add file → Upload files**.
2. Arraste o arquivo **`duartec-app.zip`**, sem descompactar, e clique em **Commit changes**.

**2.5 Criar os dois arquivos de texto**
1. Clique em **Add file → Create new file**.
2. No nome, digite exatamente `API_URL.txt`, cole a URL `/exec` do Apps Script no conteúdo e clique em **Commit changes**.
3. De novo **Add file → Create new file**. No nome, digite exatamente `.github/workflows/build.yml` (as barras criam as pastas sozinhas).
4. Cole todo o conteúdo do arquivo `build.yml` (abra no Bloco de Notas, Ctrl+A, Ctrl+C) e clique em **Commit changes**.

**2.6 Esperar o APK ficar pronto**
1. Clique na aba **Actions**. Aparece "Gerar APK e publicar site" rodando (bolinha amarela).
2. Em uns 4 minutos ela fica com um ✓ verde.
   - Se ficar ❌ vermelho: abra a execução, clique no passo com erro e me mande um print. Se o erro falar de Pages, confira o passo 2.3 e clique em **Re-run all jobs**.
3. O endereço do site aparece dentro da execução, no quadro *deploy*: `https://SEU-USUARIO.github.io/duartec-app/`.

Para trocar a URL da planilha depois: no GitHub, abra `API_URL.txt`, clique no lápis ✏️, edite e clique em **Commit changes**. O Actions gera tudo de novo sozinho.

### 3. Seu acesso de gestor
Abra no computador `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/app/` e digite o código de gestor.

## Dar acesso a um técnico
1. No app, vá em **Ajustes → Usuários e links de acesso**, digite o nome e toque em **Criar acesso**.
2. Toque em **Enviar no WhatsApp**.
3. O técnico abre o link e segue a página: **Baixar o app → Instalar → Abrir o app**. O app já entra no nome dele.

Para cortar o acesso de alguém, toque em **Desativar**.

## Atualizações
- **Mudanças no app** (pasta `www/`): chegam sozinhas em todos os celulares depois que o Actions termina, sem reinstalar.
- **Mudanças no APK** (pasta `android/`): o técnico baixa de novo pelo mesmo link e instala por cima. Os dados e o login continuam.

## Observações
- O repositório precisa ser **público** para o GitHub Pages funcionar no plano gratuito. Os dados ficam só na planilha e cada acesso exige um código.
- No iPhone não existe APK: o técnico usa o app pelo Safari e pode adicioná-lo à Tela de Início.
