package br.com.duartec.custos;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

/**
 * App Duartec Custos: uma janela que abre o app web publicado no GitHub Pages.
 * Assim, mudanças no app web chegam a todos os celulares sem reinstalar o APK.
 */
public class MainActivity extends Activity {

    private static final int REQ_FOTO = 41;
    private static final String HOST_LOCAL = "appassets.androidplatform.net";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private SharedPreferences prefs;
    private Uri appUri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("duartec", MODE_PRIVATE);
        appUri = Uri.parse(BuildConfig.APP_URL);

        web = new WebView(this);
        web.setBackgroundColor(0xFF04080A);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setUserAgentString(s.getUserAgentString() + " DuartecApp/" + BuildConfig.VERSION_NAME);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Ponte(), "DuartecApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if ("duartec-retry".equals(u.getScheme())) { abrirApp(); return true; }
                if (ehDoApp(u)) return false;
                abrirFora(u);
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) mostrarOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                return escolherFoto();
            }
        });

        if (state != null) {
            web.restoreState(state);
        } else {
            lerToken(getIntent());
            abrirApp();
        }
    }

    /** Endereço do app, com o código do usuário quando ele veio por link. */
    private void abrirApp() {
        String token = prefs.getString("u", "");
        String url = BuildConfig.APP_URL + (token.isEmpty() ? "" : "?u=" + Uri.encode(token));
        web.loadUrl(url);
    }

    private boolean ehDoApp(Uri u) {
        if (HOST_LOCAL.equals(u.getHost())) return true;
        String path = u.getPath() == null ? "" : u.getPath();
        String appPath = appUri.getPath() == null ? "/" : appUri.getPath();
        return appUri.getHost() != null && appUri.getHost().equalsIgnoreCase(u.getHost()) && path.startsWith(appPath);
    }

    private void abrirFora(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception ignored) { }
    }

    /** duartec://entrar?u=CODIGO — vindo da página de convite. */
    private boolean lerToken(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data == null || !"duartec".equals(data.getScheme())) return false;
        String u = data.getQueryParameter("u");
        if (u != null && u.trim().length() >= 6) {
            prefs.edit().putString("u", u.trim().toUpperCase()).apply();
            return true;
        }
        return false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (lerToken(intent)) abrirApp();
    }

    private void mostrarOffline() {
        String html = "<h2>Sem internet</h2>";
        try (InputStream in = getAssets().open("offline.html")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            html = out.toString("UTF-8");
        } catch (Exception ignored) { }
        web.loadDataWithBaseURL("https://" + HOST_LOCAL + "/", html, "text/html", "UTF-8", null);
    }

    /** Foto do comprovante: câmera ou galeria. */
    private boolean escolherFoto() {
        Intent galeria = new Intent(Intent.ACTION_GET_CONTENT);
        galeria.addCategory(Intent.CATEGORY_OPENABLE);
        galeria.setType("image/*");
        Intent chooser = Intent.createChooser(galeria, "Foto do comprovante");
        cameraUri = null;
        try {
            File dir = new File(getCacheDir(), "camera");
            if (!dir.exists()) dir.mkdirs();
            File foto = File.createTempFile("comprovante_", ".jpg", dir);
            cameraUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", foto);
            Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
        } catch (Exception ignored) {
            cameraUri = null;
        }
        try {
            startActivityForResult(chooser, REQ_FOTO);
            return true;
        } catch (Exception e) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = null;
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FOTO || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) result = new Uri[]{data.getData()};
            else if (cameraUri != null) result = new Uri[]{cameraUri};
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.dtBack&&window.dtBack())?'1':'0'", v -> {
            if (v == null || !v.contains("1")) finish();
        });
    }

    /** Ponte usada pelo app web para guardar/apagar o código do usuário no aparelho. */
    private class Ponte {
        @JavascriptInterface
        public void salvar(String token) {
            if (token != null && token.trim().length() >= 6) prefs.edit().putString("u", token.trim().toUpperCase()).apply();
        }

        @JavascriptInterface
        public void sair() {
            prefs.edit().remove("u").apply();
        }
    }
}
