// Endereço da API (Apps Script). Depois de implantar o Apps Script como "App da Web",
// cole aqui a URL que termina em /exec e salve (Commit). O GitHub gera tudo de novo sozinho.
window.DT_API = "COLE_AQUI_A_URL_DO_APPS_SCRIPT";
